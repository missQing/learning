var gulp = require('gulp'),
    less = require('gulp-less'),
    minifycss = require('gulp-minify-css'),
    concat = require('gulp-concat'),
    uglify = require('gulp-uglify'),
    rename = require('gulp-rename'),
    jshint=require('gulp-jshint'),
    notify = require('gulp-notify'),
    plumber = require('gulp-plumber'),
    mcss = require('gulp-mcss');

// less
gulp.task('less', function () {
    gulp.src(['E:/workspace/mmall-parent_151009/mmall-front-web/wap-web/src/main/resources/public/src/less/*.less','!src/less/extend/{reset,test}.less'])
        .pipe(plumber({errorHandler: notify.onError('Error: <%= error.message %>')}))
        .pipe(less())
        .pipe(gulp.dest('E:/workspace/mmall-parent_151009/mmall-front-web/wap-web/src/main/resources/public/src/less'));
});

// mcss
gulp.task('mcss', function() {
   gulp.src('src/mcss/*.mcss')
        .pipe(mcss())
        .pipe(rename({extname:".css"}))   //rename压缩后的文件名
        .pipe(gulp.dest('src/css'));
});

gulp.task('watch', function () {
    gulp.watch('E:/workspace/mmall-parent_151009/mmall-front-web/wap-web/src/main/resources/public/src/less/*.less', ['less']); //当所有less文件发生改变时,调用less任务
    //gulp.watch('src/**/*.mcss', ['mcss']); //当所有mcss文件发生改变时,调用mcss任务
});

//语法检查
gulp.task('jshint', function () {
    return gulp.src('src/js/*.js')
        .pipe(jshint())
        .pipe(jshint.reporter('default'));
});

//压缩css
gulp.task('minifycss', function() {
    return gulp.src('src/css/*.css')    //需要操作的文件
    	.pipe(concat('main.css'))    //合并所有css到main.css
    	.pipe(gulp.dest('src/css'))       //输出到文件夹
        .pipe(rename({suffix: '.min'}))   //rename压缩后的文件名
        .pipe(minifycss())   //执行压缩
        .pipe(gulp.dest('src/css'));   //输出文件夹
});

//压缩,合并 js
gulp.task('minifyjs', function() {
    return gulp.src('src/js/*.js')      //需要操作的文件
        .pipe(concat('main.js'))    //合并所有js到main.js
        .pipe(gulp.dest('src/js'))       //输出到文件夹
        .pipe(rename({suffix: '.min'}))   //rename压缩后的文件名
        .pipe(uglify())    //压缩
        .pipe(gulp.dest('src/js'));  //输出
});


//默认命令,在cmd中输入gulp后,执行的就是这个任务(压缩js需要在检查js之后操作)
gulp.task('default',['jshint'],function() {
    gulp.start('minifycss','minifyjs'); 
});